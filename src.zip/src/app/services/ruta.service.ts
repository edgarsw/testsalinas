import { Injectable } from '@angular/core';

const BASE_URL = "https://6edeayi7ch.execute-api.us-east-1.amazonaws.com/v1/examen";

@Injectable({
  providedIn: 'root'
})
export class RutaService {

  constructor() { }

  urlServicio():string{
    return BASE_URL;
  }
}
