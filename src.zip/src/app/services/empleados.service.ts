import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RutaService } from './ruta.service';
import { map } from "rxjs/operators";
import { IEmpleadoModel } from '../models/iempleado.model';

@Injectable({
  providedIn: 'root'
})
export class EmpleadosService {

  private URL = this.ruta.urlServicio();
  constructor(
    private httpClient: HttpClient,
    private ruta: RutaService
  ) { }

  getEmpleados() {
    return this.httpClient.get(`${this.URL}/employees/edgar_salinas`)
      .pipe((
        map((respuesta: IEmpleadoModel[]) =>
          respuesta['data'].employees
        )
      ))
  }

  getEmpleadosXIdGrupo($idGrupo: number) {
    return this.httpClient.get(`${this.URL}/employees/edgar_salinas/getByGroup?id=${$idGrupo}`)
      .pipe((
        map((respuesta: IEmpleadoModel[]) =>
          respuesta['data'].employees
        )
      ))
  }

  ins(solicitud: any) {
    return this.httpClient.post(`${this.URL}/employees/edgar_salinas`, solicitud);
  }
}
