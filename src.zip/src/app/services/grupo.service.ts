import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RutaService } from './ruta.service';
import { map } from "rxjs/operators";
import { IGrupoModel } from '../models/igrupo.model';

@Injectable({
  providedIn: 'root'
})
export class GrupoService {

  private URL = this.ruta.urlServicio();
  constructor(
    private httpClient: HttpClient,
    private ruta: RutaService
  ) { }

  getGrupos() {
    return this.httpClient.get(`${this.URL}/groups/edgar_salinas`)
      .pipe((
        map((respuesta: IGrupoModel[]) =>
          respuesta['data'].groups
        )
      ))
  }
}
