import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmpleadosComponent } from './components/empleados/empleados.component';
import { GruposComponent } from './components/grupos/grupos.component';
import { InicioComponent } from './components/inicio/inicio.component';
import { OauthGuard } from './guards/oauth.guard';

const routes: Routes = [
  { path: 'inicio', component: InicioComponent },
  { path: 'empleados', component: EmpleadosComponent, canActivate: [OauthGuard]},
  { path: 'grupos', component: GruposComponent, canActivate: [OauthGuard]},
  { path: '**', pathMatch: 'full', redirectTo: 'inicio' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
