import { Component, OnInit } from '@angular/core';
import { MatCarousel, MatCarouselComponent } from '@ngmodule/material-carousel';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  styles: [
  ]
})
export class InicioComponent implements OnInit {

  slides = [{'image': 'assets/images/cartografia.png'}, {'image': 'assets/images/impuesto.png'},{'image': 'assets/images/pagos.png'}, {'image': 'assets/images/tramites.png'}, {'image': 'assets/images/playstore.png'}];

  constructor() { }

  ngOnInit(): void {
  }

}
