import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';

import { EmpleadosService } from 'src/app/services/empleados.service';
import { IEmpleadoModel } from 'src/app/models/iempleado.model';
import { EmpleadoInsComponent } from './empleado-ins.component';

@Component({
  selector: 'app-empleados',
  templateUrl: './empleados.component.html',
  styles: [
  ]
})
export class EmpleadosComponent implements OnInit, AfterViewInit {
  progress: boolean;

  displayedColumns: string[] = ['nombre', 'apellido'];
  dataSource: MatTableDataSource<IEmpleadoModel> = new MatTableDataSource();


  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(
    private empleadoService: EmpleadosService,
    private snackBar: MatSnackBar,
    public dialog: MatDialog
  ) {
    this.progress = true;
    this.getEmpleados();
  }



  ngOnInit(): void {
  }

  getEmpleados() {
    this.empleadoService.getEmpleados().subscribe(
      respuesta => {
        this.progress = false;
        this.dataSource.data = respuesta;
      }, error => {
        this.openSnackBar("Error al recuperar empleados", "Cerrar");
        this.progress = false;
      }
    );
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;

    const paginatorIntl = this.paginator._intl;
    paginatorIntl.nextPageLabel = 'Siguiente';
    paginatorIntl.previousPageLabel = 'Regreso';
    paginatorIntl.itemsPerPageLabel = 'Registros por p\u00E1gina';
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
  }

  openDialogIns() {
    let dialogRef = this.dialog.open(EmpleadoInsComponent);

    dialogRef.afterClosed().subscribe(
      result => {

        if (typeof result !== "undefined" && result != false) {
          this.progress = true;
          this.empleadoService.ins(result).
            subscribe(respuesta => {
              this.getEmpleados();
              this.progress = false;
              this.openSnackBar("Empleado guardado con \u00E9xito", "Cerrar");
            }, error => {
              this.progress = false;
              this.openSnackBar("Error al guardar empleado", "Cerrar");
            }
            );
        }
      }
    );
  }

}
