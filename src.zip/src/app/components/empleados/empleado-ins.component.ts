import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-empleado-ins',
  templateUrl: './empleado-ins.component.html',
  styles: [
  ]
})
export class EmpleadoInsComponent implements OnInit {

  myGroup: FormGroup;
  progress: boolean;

  constructor(
    private formBuilder: FormBuilder,
    private snackBar: MatSnackBar,
    private dialogRef: MatDialogRef<EmpleadoInsComponent>,
  ) { 
    this.progress = false;
    this.createForm();
  }

  ngOnInit(): void {
  }

  createForm() {
    this.myGroup = this.formBuilder.group({
      name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(30)]],
      last_name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(30)]],
      birthday: ['', [Validators.required]]
    })
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
  }

  campoNoValido(campo) {
    return this.myGroup.get(campo).invalid && this.myGroup.get(campo).touched
  }

  onSubmit() {
    if (this.myGroup.valid) {
      let respuesta = {
        name: this.myGroup.get('name').value,
        last_name: this.myGroup.get('last_name').value,
        birthday: this.myGroup.get('birthday').value
      }
      this.dialogRef.close(respuesta)      
    } else {
      Object.values(this.myGroup.controls).forEach(control => {
        control.markAsTouched();
      })
      this.openSnackBar("Formulario con errores", "Cerrar");
    }
  }

  close(){
    //puede solo cerrarse el modal
    //this.dialogRef.close()
    this.dialogRef.close(false);
  }

}
