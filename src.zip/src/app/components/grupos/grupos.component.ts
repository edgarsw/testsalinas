import { Component, OnInit } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { GrupoService } from 'src/app/services/grupo.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { IGrupoModel } from 'src/app/models/igrupo.model';
import { EmpleadosService } from 'src/app/services/empleados.service';
import { IEmpleadoModel } from 'src/app/models/iempleado.model';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-grupos',
  templateUrl: './grupos.component.html',
  styles: [
  ]
})
export class GruposComponent implements OnInit {

  progress: boolean;
  todo = [];

  displayedColumns: string[] = ['checkempleado', 'nombre', 'apellido'];
  dataSource: MatTableDataSource<IEmpleadoModel> = new MatTableDataSource();

  grupos: IGrupoModel[] = [];
  empleados : IEmpleadoModel[];
  done: string[] = [
  ];

  grupo: IGrupoModel;

  constructor(
    private snackBar: MatSnackBar,
    private grupoService: GrupoService,
    private empleadoService: EmpleadosService
  ) {
    this.grupo = null;
    this.progress = true;
    this.getGrupos();
  }

  ngOnInit(): void {
  }

  getGrupos() {
    this.grupoService.getGrupos().subscribe(
      (respuesta: IGrupoModel[]) => {
        let i = 0;
        this.grupos = respuesta;
        /*
        respuesta.forEach(
          e => {
            this.todo[i++] = e.name;
          }
        );*/
        this.progress = false;
        this.openSnackBar("Grupos recuperados con \u00E9xito", "Cerrar");
      }, error => {
        this.progress = false;
        this.openSnackBar("Error al recuperar los grupos", "Cerrar");
      }
    );
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
  }



  drop(event: CdkDragDrop<IEmpleadoModel[]>) {
    if (event.previousContainer === event.container) {      
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
        this.grupo = this.grupos[event.previousIndex];
        this.done[0] = this.grupo.name;
        this.progress = true;
        this.getEmpleadosXIdGrupo();

    }
  }

  getEmpleadosXIdGrupo() {
    this.empleadoService.getEmpleadosXIdGrupo(this.grupo.id).subscribe(
      (respuesta: IEmpleadoModel[]) => {
        this.empleados = respuesta;
        this.dataSource.data = respuesta;
        this.progress = false;
        this.openSnackBar("Empleados recuperados con \u00E9xito", "Cerrar");
      }, error => {
        this.progress = false;
        this.openSnackBar("Error al recuperar los empleados", "Cerrar");
      }
    );
  }

  limpiarGrupo(){
    this.done = [];
    this.dataSource.data = [];
  }

}
