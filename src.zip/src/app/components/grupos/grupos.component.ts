import { Component, OnInit } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { GrupoService } from 'src/app/services/grupo.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { IGrupoModel } from 'src/app/models/igrupo.model';
import { EmpleadosService } from 'src/app/services/empleados.service';
import { IEmpleadoModel } from 'src/app/models/iempleado.model';

@Component({
  selector: 'app-grupos',
  templateUrl: './grupos.component.html',
  styles: [
  ]
})
export class GruposComponent implements OnInit {

  progress: boolean;
  todo = [];

  grupos: IGrupoModel[];
  empleados : IEmpleadoModel[];
  done = [
  ];

  constructor(
    private snackBar: MatSnackBar,
    private grupoService: GrupoService,
    private empleadoService: EmpleadosService
  ) {
    this.progress = true;
    this.getGrupos();
  }

  ngOnInit(): void {
  }

  getGrupos() {
    this.grupoService.getGrupos().subscribe(
      (respuesta: IGrupoModel[]) => {
        let i = 0;
        this.grupos = respuesta;
        respuesta.forEach(
          e => {
            this.todo[i++] = e.name;
          }
        );
        this.progress = false;
        this.openSnackBar("Grupos recuperados con \u00E9xito", "Cerrar");
      }, error => {
        this.progress = false;
        this.openSnackBar("Error al recuperar los grupos", "Cerrar");
      }
    );
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
  }



  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {      
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
        this.progress = true;
        this.getEmpleadosXIdGrupo( this.grupos[event.currentIndex]);

    }
  }

  getEmpleadosXIdGrupo(grupo : IGrupoModel) {
    this.empleadoService.getEmpleadosXIdGrupo(grupo.id).subscribe(
      (respuesta: IEmpleadoModel[]) => {
        let i = 0;
        this.empleados = respuesta;
        this.done[i++] = grupo.name;
        respuesta.forEach(
          e => {
            this.done[i++] = e.name;
          }
        );
        this.progress = false;
        this.openSnackBar("Empleados recuperados con \u00E9xito", "Cerrar");
      }, error => {
        this.progress = false;
        this.openSnackBar("Error al recuperar los empleados", "Cerrar");
      }
    );
  }



}
