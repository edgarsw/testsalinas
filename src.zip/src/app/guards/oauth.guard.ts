import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OauthGuard implements CanActivate {
  constructor(
    private router: Router) {
  }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {
     
      if (!this.validaRuta(state.url)) {
        this.router.navigateByUrl("/inicio");
        return false;
      }
      return true;
  }

  validaRuta(ruta : string): boolean{
    let valida = false;
    switch(ruta){
      case '/empleados': valida = true; break;
      case '/grupos': valida = true; break;
    }
    return valida;
  }
  
}
