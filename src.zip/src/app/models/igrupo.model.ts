export interface IGrupoModel {
    id: number,
    name: string
}