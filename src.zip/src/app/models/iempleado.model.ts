export interface IEmpleadoModel {
    id: number,
    name: string,
    last_name: string,
    birthday: string
}